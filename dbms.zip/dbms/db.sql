-- Create the Hospital Management Database
CREATE DATABASE IF NOT EXISTS hospital_management;
-- Use the hospital_management database
USE hospital_management;
-- Create the hospital data table with columns: patientid, name, email, department, doctorassigned, action
CREATE TABLE IF NOT EXISTS hospital_data (
    patientid INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    doctorassigned VARCHAR(100) NOT NULL,
    action VARCHAR(100) NOT NULL
);
-- Insert sample data into the hospital_data table
INSERT INTO hospital_data (name, email, department, doctorassigned, action) VALUES
('John Doe', 'john.doe@example.com', 'Cardiology', 'Dr. John Doe', 'Admitted'),
('Sarah Green', 'sarah.green@example.com', 'Neurology', 'Dr. Jane Smith', 'Under Observation'),
('Michael Scott', 'michael.scott@example.com', 'Orthopedics', 'Dr. Alice Brown', 'Discharged'),
('Emma White', 'emma.white@example.com', 'Pediatrics', 'Dr. Bob White', 'Admitted');
-- Query to view all data from the hospital_data table
SELECT * FROM hospital_data;
