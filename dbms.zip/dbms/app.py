from flask import Flask, render_template, redirect, request, url_for
from flask_mysqldb import MySQL

app = Flask(__name__)
app.secret_key = 'tamil'

# MySQL Database Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'sri2006'  # Change this to your actual MySQL password
app.config['MYSQL_DB'] = 'hospital_management'  # Database name
mysql = MySQL(app)

# Home Page
@app.route('/')
def index():
    return render_template('index.html')

# Patients List Page
@app.route('/patients')
def patients():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM hospital_data")  # Fetching data from the hospital_data table
    patient_info = cur.fetchall()
    cur.close()
    return render_template('patients.html', patients=patient_info)  # Display patients

# Search for a Patient by ID
@app.route('/search', methods=['POST'])
def search():
    search_results = []
    if request.method == "POST":
        search_term = request.form['patientid']
        cur = mysql.connection.cursor()
        query = "SELECT * FROM hospital_data WHERE patientid LIKE %s"
        cur.execute(query, ('%' + search_term + '%',))
        search_results = cur.fetchall()  # Fetch search results
        cur.close()
        return render_template('patients.html', patients=search_results)
    return redirect(url_for('patients'))  # Redirect to patients list if GET request

# Add a New Patient
@app.route('/add_patient', methods=['POST', 'GET'])
def add_patient():
    if request.method == 'POST':
        patientid = request.form['patientid']
        name = request.form['name']
        email = request.form['email']
        department = request.form['department']
        doctorassigned = request.form['doctorassigned']
        action = request.form['action']

        cur = mysql.connection.cursor()
        cur.execute(""" 
            INSERT INTO hospital_data (patientid, name, email, department, doctorassigned, action)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (patientid, name, email, department, doctorassigned, action))
        mysql.connection.commit()  # Commit the transaction
        cur.close()
        return redirect(url_for('patients'))

    return render_template('add_patient.html')  # Show form to add new patient

# Delete a Patient
@app.route('/delete/<string:patientid>', methods=['GET'])
def delete(patientid):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM hospital_data WHERE patientid = %s", (patientid,))
    mysql.connection.commit()
    return redirect(url_for('patients'))  # Redirect after deletion

# Update a Patient's Data
@app.route('/update/<string:patientid>', methods=['POST', 'GET'])
def update(patientid):
    cur = mysql.connection.cursor()

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        department = request.form['department']
        doctorassigned = request.form['doctorassigned']
        action = request.form['action']

        cur.execute("UPDATE hospital_data SET name = %s, email = %s, department = %s, doctorassigned = %s, action = %s WHERE patientid = %s",
                    (name, email, department, doctorassigned, action, patientid))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('patients'))

    else:
        cur.execute("SELECT * FROM hospital_data WHERE patientid = %s", (patientid,))
        patient_data = cur.fetchone()  # Fetch the patient data by patientid
        cur.close()

        if patient_data:
            return render_template('update_patient.html', patient=patient_data)
        else:
            return redirect(url_for('patients'))  # Redirect if patient not found


if __name__ == "__main__":
    app.run(debug=True)
